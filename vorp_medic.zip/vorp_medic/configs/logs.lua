local Logs = {
    Webhook         =       "",                 --add webhook for all other Police logs Url here 
    StorageWebook   =       "",                 --add Storage webhook Url here
    DutyWebhook     =       "",                 --add Duty webhook Url here
    
    
    
    
    Namelogs        = "Medic logs ",
    color           = 16711680,                      -- color for webhook embeds or defualts to set in vorp core config
    logo            = "",                            -- Logo URL for webhook embeds. or defualts to set in vorp core config
    footerLogo      = "",                            -- Footer logo URL for webhook embeds. or defualts to set in vorp core config
    Avatar          = "",                            -- Avatar URL for webhook embeds. or defualts to set in vorp core config



    Lang = {
        Steam           = "Steam: ",
        Jobfired        = "Medic Fired: ",
        JobHired        = "Medic Hired: ",
        JobOnDuty       = "Medic On Duty: ",       
        JobOffDuty      = "Medic Off Duty: ",     
        Identifier      = "Identifier: ",
        FiredPlayer     = "Fired Player: ",
        HiredPlayer     = "Hired Player: ",
        PlayerID        = "Player ID: ",
        HiredBy         = "Hired By: ",
        FiredBy         = "Fired By: ",
        FromJob         = "From Job: ",
        Job             = "Job",
        PlayerName      = "Player Name: "  
    },

}

return {
    Logs = Logs,
}