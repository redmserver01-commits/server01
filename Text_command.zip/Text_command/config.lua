Config = {}

Config.DisplayDistance = 15.0
Config.DisplayTime = 5000
Config.FloatSpeed = 0.0008

Config.Cooldown = 2000
Config.MaxLength = 120

Config.Colors = {
    me = {255,255,255},
    do = {200,200,200},
    success = {0,255,0},
    fail = {255,0,0},
    ooc = {180,180,180}
}