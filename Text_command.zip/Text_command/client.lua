local characterName = nil
local activeTexts = {}
local lastUsed = 0

RegisterNetEvent("dfthai3d:returnCharacterName")
AddEventHandler("dfthai3d:returnCharacterName", function(name)
    characterName = name
end)

RegisterNetEvent("vorp:SelectedCharacter")
AddEventHandler("vorp:SelectedCharacter", function()
    TriggerServerEvent("dfthai3d:getCharacterName")
end)

function GetRPName()
    return characterName or GetPlayerName(PlayerId())
end

local function CanUse()
    if GetGameTimer() - lastUsed < Config.Cooldown then
        return false
    end
    lastUsed = GetGameTimer()
    return true
end

local function Send3D(text,type)
    if string.len(text) > Config.MaxLength then return end
    if not CanUse() then return end

    local coords = GetEntityCoords(PlayerPedId())
    TriggerServerEvent("dfthai3d:send", text, type, coords)
end

-- COMMANDS

RegisterCommand("me", function(_,args)
    if #args<1 then return end
    local text = table.concat(args," ")
    local name = GetRPName()

    Send3D(text,"me")

    TriggerEvent("chat:addMessage",{
        args = {"^5[ME] "..name.."^0", text},
        color = Config.Colors.me
    })
end)

RegisterCommand("do", function(_,args)
    if #args<1 then return end
    local text = table.concat(args," ")
    local name = GetRPName()

    Send3D(text,"do")

    TriggerEvent("chat:addMessage",{
        args = {"^3[DO] "..name.."^0", text},
        color = Config.Colors.do
    })
end)

RegisterCommand("try", function(_,args)
    if #args<1 then return end
    local success = math.random(1,2)==1
    local result = success and "สำเร็จ" or "ล้มเหลว"
    local text = table.concat(args," ").." | "..result
    local name = GetRPName()

    Send3D(text, success and "success" or "fail")

    TriggerEvent("chat:addMessage",{
        args = {success and "^2[TRY] "..name.."^0" or "^1[TRY] "..name.."^0", text},
        color = success and Config.Colors.success or Config.Colors.fail
    })
end)

RegisterCommand("b", function(_,args)
    if #args<1 then return end
    local text = "(( "..table.concat(args," ").." ))"
    local name = GetRPName()

    Send3D(text,"ooc")

    TriggerEvent("chat:addMessage",{
        args = {"^8[OOC] "..name.."^0", text},
        color = Config.Colors.ooc
    })
end)

RegisterNetEvent("dfthai3d:receive")
AddEventHandler("dfthai3d:receive", function(serverId,text,type)
    local player = GetPlayerFromServerId(serverId)
    if player==-1 then return end

    table.insert(activeTexts,{
        player=player,
        text=text,
        type=type,
        expire=GetGameTimer()+Config.DisplayTime,
        offset=0.0
    })
end)

-- MAIN LOOP

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(5)
        local myCoords = GetEntityCoords(PlayerPedId())

        for i=#activeTexts,1,-1 do
            local v = activeTexts[i]
            if GetGameTimer()>v.expire then
                table.remove(activeTexts,i)
            else
                local ped = GetPlayerPed(v.player)
                if DoesEntityExist(ped) then
                    local coords = GetEntityCoords(ped)
                    local dist = #(coords-myCoords)

                    if dist<Config.DisplayDistance then
                        v.offset = v.offset + Config.FloatSpeed
                        local onScreen,x,y = GetScreenCoordFromWorldCoord(coords.x,coords.y,coords.z+1.0+v.offset)

                        if onScreen then
                            SendNUIMessage({
                                action="show",
                                text=v.text,
                                x=x,
                                y=y,
                                type=v.type
                            })
                        end
                    end
                end
            end
        end
    end
end)