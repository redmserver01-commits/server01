window.addEventListener("message",function(e){
    if(e.data.action==="show"){
        const div=document.createElement("div");
        div.className="text3d "+e.data.type;
        div.style.left=(e.data.x*100)+"%";
        div.style.top=(e.data.y*100)+"%";
        div.innerText=e.data.text;

        document.body.appendChild(div);

        setTimeout(()=>{
            div.style.transition="opacity 0.5s";
            div.style.opacity="0";
            setTimeout(()=>div.remove(),500);
        },4500);
    }
});