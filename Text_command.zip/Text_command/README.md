---Um pequeno simples com vários comandos me/ooc/estado/tentar/acao

---A simple little one with several me/ooc/state/try/action commands


![Screenshot_1](https://github.com/DFGitZ/DF_Comands/assets/168344868/b2606476-9331-44f8-911d-144d7a733c81)



Preview
https://www.youtube.com/watch?v=YZypEsoGa1M&ab_channel=DF
